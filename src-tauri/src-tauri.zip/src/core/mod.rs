//! Core application modules

pub mod app;

/// Re-exports
pub use app::AppState;
//! Services module
//!
//! This module contains business logic services for the application.

pub mod ai;
pub mod terminal;


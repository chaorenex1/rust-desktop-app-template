//! Tauri modules

pub mod commands;
pub mod events;

